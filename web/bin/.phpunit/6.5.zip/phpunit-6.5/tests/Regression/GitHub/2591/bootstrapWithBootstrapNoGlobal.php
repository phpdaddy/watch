<?php
// $globalString                          = 'Hello';

require __DIR__ . '/../../../bootstrap.php';